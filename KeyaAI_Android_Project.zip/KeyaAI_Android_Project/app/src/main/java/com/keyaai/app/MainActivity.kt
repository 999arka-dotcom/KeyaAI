package com.keyaai.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val role: String,
    val text: String,
    val attachmentUri: String? = null,
    val attachmentMime: String? = null
)

data class ChatThread(
    val id: String = UUID.randomUUID().toString(),
    val title: String = "Новый чат",
    val messages: List<ChatMessage> = emptyList()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MyAIApp() }
    }
}

private fun loadChats(context: Context): List<ChatThread> {
    return try {
        val raw = context.getSharedPreferences("myai", Context.MODE_PRIVATE)
            .getString("chats", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val obj = arr.getJSONObject(i)
            val msgs = obj.getJSONArray("messages")
            ChatThread(
                id = obj.getString("id"),
                title = obj.getString("title"),
                messages = (0 until msgs.length()).map { j ->
                    val m = msgs.getJSONObject(j)
                    ChatMessage(
                        id = m.getString("id"),
                        role = m.getString("role"),
                        text = m.getString("text"),
                        attachmentUri = m.optString("attachmentUri").takeIf { it.isNotBlank() && it != "null" },
                        attachmentMime = m.optString("attachmentMime").takeIf { it.isNotBlank() && it != "null" }
                    )
                }
            )
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveChats(context: Context, chats: List<ChatThread>) {
    val arr = JSONArray()
    chats.forEach { chat ->
        val obj = JSONObject()
        obj.put("id", chat.id)
        obj.put("title", chat.title)
        val messages = JSONArray()
        chat.messages.forEach { msg ->
            messages.put(JSONObject().apply {
                put("id", msg.id)
                put("role", msg.role)
                put("text", msg.text)
                put("attachmentUri", msg.attachmentUri)
                put("attachmentMime", msg.attachmentMime)
            })
        }
        obj.put("messages", messages)
        arr.put(obj)
    }
    context.getSharedPreferences("myai", Context.MODE_PRIVATE)
        .edit().putString("chats", arr.toString()).apply()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyAIApp() {
    val context = LocalContext.current
    var chats by remember { mutableStateOf(loadChats(context)) }
    var currentId by remember { mutableStateOf(chats.firstOrNull()?.id) }
    var draft by remember { mutableStateOf("") }
    var showChats by remember { mutableStateOf(false) }
    var pendingAttachment by remember { mutableStateOf<Pair<String, String>?>(null) }

    fun persist(updated: List<ChatThread>) {
        chats = updated
        saveChats(context, updated)
    }
    fun newChat() {
        val chat = ChatThread()
        persist(listOf(chat) + chats)
        currentId = chat.id
        draft = ""
        pendingAttachment = null
    }

    val current = chats.firstOrNull { it.id == currentId }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) { }
            val mime = context.contentResolver.getType(uri) ?: "application/octet-stream"
            pendingAttachment = uri.toString() to mime
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF8AB4F8),
            secondary = Color(0xFF9AA0A6),
            background = Color(0xFF101114),
            surface = Color(0xFF191B20)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("KeyaAI", fontWeight = FontWeight.Bold)
                            Text(
                                current?.title ?: "Твой ИИ-помощник",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        TextButton(onClick = { showChats = !showChats }) { Text("Чаты") }
                    },
                    actions = {
                        IconButton(onClick = { newChat() }) {
                            Icon(Icons.Default.Add, contentDescription = "Новый чат")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                Column(
                    Modifier.fillMaxWidth()
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(10.dp)
                ) {
                    pendingAttachment?.let { (uri, mime) ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Вложение готово: ${mime.substringBefore('/')}", modifier = Modifier.weight(1f))
                            TextButton(onClick = { pendingAttachment = null }) { Text("Убрать") }
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        IconButton(onClick = {
                            picker.launch(arrayOf("image/*", "video/*", "application/pdf", "text/*"))
                        }) {
                            Icon(Icons.Default.AttachFile, contentDescription = "Прикрепить файл")
                        }
                        Box(
                            Modifier.weight(1f)
                                .background(Color(0xFF272A31), RoundedCornerShape(24.dp))
                                .padding(horizontal = 16.dp, vertical = 13.dp)
                        ) {
                            if (draft.isEmpty()) Text("Напиши сообщение…", color = Color.LightGray)
                            BasicTextField(
                                value = draft,
                                onValueChange = { draft = it },
                                modifier = Modifier.fillMaxWidth(),
                                textStyle = MaterialTheme.typography.bodyLarge.copy(color = Color.White),
                                maxLines = 5
                            )
                        }
                        IconButton(onClick = {
                            val text = draft.trim()
                            if (text.isNotEmpty() || pendingAttachment != null) {
                                val base = current ?: ChatThread()
                                val userMessage = ChatMessage(
                                    role = "user",
                                    text = text,
                                    attachmentUri = pendingAttachment?.first,
                                    attachmentMime = pendingAttachment?.second
                                )
                                val title = if (base.messages.isEmpty() && text.isNotBlank())
                                    text.take(32) else base.title
                                val updatedChat = base.copy(
                                    title = title,
                                    messages = base.messages + userMessage
                                )
                                val all = if (chats.any { it.id == base.id })
                                    chats.map { if (it.id == base.id) updatedChat else it }
                                else listOf(updatedChat) + chats
                                persist(all)
                                currentId = base.id
                                draft = ""
                                pendingAttachment = null
                                val info = ChatMessage(
                                    role = "assistant",
                                    text = "Чат сохранён на устройстве. Движок языковой модели пока не подключён — это стартовая версия KeyaAI. Следующим этапом подключим модель, которая будет генерировать ответы на телефоне."
                                )
                                persist(all.map { if (it.id == base.id) it.copy(messages = it.messages + info) else it })
                            }
                        }) {
                            Icon(Icons.Default.Send, contentDescription = "Отправить")
                        }
                    }
                }
            }
        ) { padding ->
            Row(Modifier.fillMaxSize().padding(padding)) {
                if (showChats) {
                    Column(
                        Modifier.width(180.dp).fillMaxHeight()
                            .background(Color(0xFF14161A)).padding(8.dp)
                    ) {
                        Button(onClick = { newChat(); showChats = false }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Новый чат")
                        }
                        Spacer(Modifier.height(8.dp))
                        LazyColumn {
                            items(chats, key = { it.id }) { chat ->
                                Row(
                                    Modifier.fillMaxWidth()
                                        .background(if (chat.id == currentId) Color(0xFF303641) else Color.Transparent,
                                            RoundedCornerShape(10.dp))
                                        .clickable { currentId = chat.id; showChats = false }
                                        .padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(chat.title, modifier = Modifier.weight(1f), maxLines = 2)
                                    IconButton(onClick = {
                                        val updated = chats.filterNot { it.id == chat.id }
                                        persist(updated)
                                        if (currentId == chat.id) currentId = updated.firstOrNull()?.id
                                    }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Удалить чат")
                                    }
                                }
                            }
                        }
                    }
                }

                if (current == null || current.messages.isEmpty()) {
                    Column(
                        Modifier.fillMaxSize().padding(24.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("Привет, я KeyaAI", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Создавай чаты, сохраняй переписки и прикрепляй фото или видео. Подключение ИИ-модели — следующий этап.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                        contentPadding = PaddingValues(vertical = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        items(current.messages, key = { it.id }) { msg ->
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = if (msg.role == "user") Arrangement.End else Arrangement.Start
                            ) {
                                Column(
                                    Modifier.widthIn(max = 320.dp)
                                        .background(
                                            if (msg.role == "user") Color(0xFF28466B) else Color(0xFF202329),
                                            RoundedCornerShape(16.dp)
                                        )
                                        .padding(12.dp)
                                ) {
                                    Text(if (msg.role == "user") "Ты" else "KeyaAI",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = Color(0xFFB9C9E3))
                                    if (msg.text.isNotBlank()) {
                                        Spacer(Modifier.height(4.dp))
                                        Text(msg.text)
                                    }
                                    if (msg.attachmentUri != null) {
                                        Spacer(Modifier.height(6.dp))
                                        Text("📎 Вложение: ${msg.attachmentMime ?: "файл"}")
                                        Text(msg.attachmentUri, style = MaterialTheme.typography.labelSmall,
                                            color = Color.LightGray, maxLines = 2)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
